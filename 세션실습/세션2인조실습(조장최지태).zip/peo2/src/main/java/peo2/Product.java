package peo2;

import java.io.IOException; 
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/product")
public class Product extends HttpServlet{

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		ShopDAO dao = new ShopDAO();
		
		ArrayList<Item> pro = dao.getItem();
		
		HttpSession session = req.getSession();
		session.getAttribute("name");
		
		req.setAttribute("product", pro);
		
		req.getRequestDispatcher("WEB-INF/views/product.jsp").forward(req, resp);
		
		
		
		
		
	}
}
