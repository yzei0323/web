package peo2;

import java.util.ArrayList;

public class ShopDAO {

	
	//고객
	public ArrayList<Customer> getCustomer(){
		
		ArrayList<Customer> list = new ArrayList<>();
		
		list.add(new Customer("u01", "1234", "김길동"));
		list.add(new Customer("u02", "4312", "최길동"));
		list.add(new Customer("u03", "2143", "이길동"));

		return list;
		
	}
	
	// 상품
	public ArrayList<Item> getItem(){
		
		ArrayList<Item> list = new ArrayList<>();
		
		list.add(new Item("p11","홈런볼", 2300, "https://i.namu.wiki/i/A2jdOHbk9lkr9La7shbtvODyYJbfpd1N3OgDtcdlCpwBt9bvqbVXQ-7iyN4_-9rchifSRpFB0tnRQh3ak7oQcDtATPAMWcSn5ixMlGyp6hJkxV6Y2tqkLWcgCZmKa_MtutlMxY8p_ny6fmec4aCnag.webp"));
		list.add(new Item("p22","빼빼로", 1200, "https://m.lottesweetmall.com/web/product/big/202206/3815b1d677b4bc7a31f30f90fe62b6a8.png"));
		list.add(new Item("p33", "몽쉘", 6000, "https://i.namu.wiki/i/iJe3Tss4Z7C1vVW96cjFIYNvCz-f7QFIz_2XcJTUPmLaZYVou2Ct2wMbtd38edeFdxOugONOMwhminHtmV6Arg.webp"));
		list.add(new Item("p44","맛동산", 2400, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBvA61xRzZXGxifcDTl4w0foCP3oSeUss1eQ&s"));
		list.add(new Item("p55","포테이토칩", 1450, "https://image.nongshim.com/non/pro/1541051410389.jpg"));
		list.add(new Item("p66","오감자", 1300, "https://i.namu.wiki/i/AfPP7n5M9izqnxuHiqy31lUC-Dc3BKyuFMGpxmzcUeR6jJeaGhDrnphPbhNCfwkgkHHxKWrajmgNbAXhPXvcbQ.webp"));
		list.add(new Item("p77","꼬깔콘", 1450, "https://m.kakamuka.com/web/product/big/202306/60144ddfdbe2ffb4c28a134de6e75d9b.jpg"));
		list.add(new Item("p88","매운새우깡", 1150, "https://img.danawa.com/prod_img/500000/426/727/img/2727426_1.jpg?_v=20180524095725&shrink=360:360"));
		list.add(new Item("p99","뿌셔뿌셔", 850, "https://shopby-images.cdn-nhncommerce.com/20241121/173602.340985000/%EB%BF%8C%EC%85%94%EB%BF%8C%EC%85%944%EC%A2%85%EB%8C%80%ED%91%9C_5%EC%9B%94%EB%B8%8C%EB%9E%9C%EB%93%9C%EB%8D%B0%EC%9D%B4.jpg"));
		list.add(new Item("p00","썬칩", 1400, "https://i.namu.wiki/i/an2yCbbSxfGV0R-j0JywVRwjG33wUC4SMx8A_oIwcnE57nVSO7Q0iAZnGporEWv5vTAGvGIPyacwvaIE4l5UXg.webp"));
		
		return list;
	}
	
	
	public String logInUser(String id, String pw) {
		
		ArrayList<Customer> user = getCustomer();
		
		for(Customer cus : user) {
			
			if(cus.getId().equals(id) && cus.getPw().equals(pw)) {
				return cus.getName();
			}
		}
		return null;
		
		
	}
	
}
